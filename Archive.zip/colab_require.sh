!wget http://nlp.stanford.edu/data/glove.6B.zip
!unzip glove*.zip